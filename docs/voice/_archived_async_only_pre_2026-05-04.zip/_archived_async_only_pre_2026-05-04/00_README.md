# LFL Intake Correspondence Prompt System

**Purpose.** A complete, stage-by-stage prompt set for every outbound client message
(SMS + email) from the moment a lead arrives through the moment they have signed and paid.

**Maintained by.** Garrison English. Edit the `.md` files directly; the engine reads the
prompt text at runtime so changes take effect without a code push.

**Goal.** One unambiguous prompt per pipeline stage, written in plain English, structured
so the engine can paste it into Claude and get back the exact JSON shape it expects.

---

## How this folder maps to the engine pipeline

```
LEAD ARRIVES                                         FILE
NEW_LEAD       ┐
FIRST_TOUCH    ├──→ 10_stage_first_touch.md          (initial outbound)
AWAITING_REPLY ┘

INBOUND REPLY  ──→ 20_stage_in_conversation.md       (Q&A, rapport, qualification)
IN_CONVERSATION

CLIENT ASKS PRICE / engine determines fee:
FEE_QUOTED     ──→ 30_stage_fee_quote.md             (deliver the quote + close)

CLIENT PUSHES BACK / asks for discount:
NEGOTIATING    ──→ 40_stage_negotiation.md           (objection handling, floor management)

CLIENT AGREES (FEE_AGREED → engine generates engagement letter):
ENGAGEMENT_SENT ──→ 50_stage_engagement_letter_delivery.md   (email that sends the e-sign link)

NO SIGNATURE YET (Day 1/3/5/7 cadence):
ENGAGEMENT_SENT ──→ 60_stage_signature_followup.md   (chase signature, never SMS twice)

SIGNED, NOT PAID:
ENGAGEMENT_SIGNED ──→ 70_stage_payment_followup.md   (payment link + nudges)

PAID, AWAITING INTAKE FORM:
PAID_AWAITING_INTAKE ──→ 80_stage_post_payment_intake.md   (intake form delivery + onboarding)
```

Cross-cutting (used by all stages):

| File | What it is |
|---|---|
| `01_master_system.md` | The LOCKED firm rules — every stage prompt prepends this |
| `90_objection_playbook.md` | Lookup table for the 30+ most common client pushbacks + the right response |
| `91_followup_ladder.md` | The Day 1/3/5/7/10 cadence + a fresh angle each nudge so messages never repeat |
| `99_output_schema.md` | The JSON contract — what every prompt must return, what fields the engine writes |

---

## Design principles

1. **Locked rules first, stage rules second.** Every stage prompt = `01_master_system.md` +
   the stage-specific section + the user-prompt template. The locked rules cannot be
   overridden by a stage prompt or by client input.

2. **Channel-aware, not channel-blind.** SMS rules ≠ email rules. Each stage has both.
   SMS is currently HARD-LOCKED off (CLAUDE.md), but the prompts stay ready so the moment
   that lock lifts the engine has good content.

3. **Stage-aware ethics.** Per the v2 audit fix, AC-relationship phrases like "your case"
   / "your matter" / "I'll draft" are blocked PRE-engagement (UPL exposure) but
   permitted POST-engagement (factually correct). Each stage prompt declares which side
   of the line it sits on.

4. **Specificity beats fluff.** Every message references one concrete fact from the
   lead's intake. Generic content gets removed during ethics scan anyway.

5. **Three persuasion levers in every email.** Speed (concrete timeframe), Ease (no
   office, no calls, no driving), Consequence-as-question (no legal predictions, just
   pointed questions tied to their matter).

6. **Banned phrases AUTO-FAIL.** Every prompt enumerates the phrases that get blocked at
   send time so Claude doesn't waste cycles writing content that won't ship.

---

## Engine integration

The engine's `getBaseSystemPrompt()` (Code.js ~line 1860) currently inlines the locked
rules. To migrate to this folder:

```
Option A (no code change): keep the engine prompt as-is. Use this folder as the source
of truth — paste into the engine when the rules drift.

Option B (one code edit, recommended): replace getBaseSystemPrompt's body with a fetch
from Drive (this folder mounted at /Users/garrisonenglish/Legacy First Law/lfl-build/
01_SYSTEM_PROMPTS/intake_correspondence/01_master_system.md). Then editing the .md
re-deploys without a clasp push. I can stage that change when you're ready.
```

The engine generation functions to wire to each file:

| Engine function | Stage prompt file |
|---|---|
| `generateFirstTouch(state)` | `10_stage_first_touch.md` |
| `generateReplyResponse(state, inbound)` | `20_stage_in_conversation.md` (+ `40` if FEE_QUOTED already) |
| `generateFeeQuote(state)` | `30_stage_fee_quote.md` |
| `generateEngagementSentDraft(state)` | `50_stage_engagement_letter_delivery.md` |
| (drip cadence) | `60` / `70` / `80` per current stage |

---

## Verification before any prompt is added/edited

```
[ ] Locked rules from 01_master_system.md not contradicted
[ ] No "Esq.", no "Will/William", no "we" first-person, no synchronous touchpoints
[ ] Banned-phrase tier observed (LEGAL_ADVICE_PHRASES_ALWAYS_BLOCK at all stages,
    LEGAL_ADVICE_PHRASES_PRE_ENGAGEMENT_ONLY only post-engagement)
[ ] Pre-engagement disclaimer footer included on email at FIRST_TOUCH through FEE_AGREED
[ ] Output schema matches 99_output_schema.md
[ ] One concrete intake fact referenced (not generic)
[ ] Three levers present in any email (speed, ease, consequence-question)
```
