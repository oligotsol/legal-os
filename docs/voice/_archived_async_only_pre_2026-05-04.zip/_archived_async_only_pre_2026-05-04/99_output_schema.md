# Output JSON Schema (the contract every prompt returns)

Every stage prompt returns ONE JSON object matching this schema. No prose around it.
The engine parses this JSON and writes the relevant fields to the conversation sheet.

---

## Schema

```json
{
  "sms": "string — SMS draft (under 320 chars). Empty string if SMS is not appropriate for this stage. SMS is currently HARD-LOCKED off — drafts are queued for Garrison review, not sent.",
  "email_subject": "string — email subject line. Specific to the matter, never generic.",
  "email_body_text": "string — plain text email body. Required for client compatibility. Includes \\n line breaks.",
  "email_body_html": "string — HTML version of the email body. Should mirror email_body_text exactly in content; HTML formatting only. Use <p>, <ul>, <li>, <strong> — no inline styles, no <div>, no fonts.",
  "new_stage": "string — the pipeline stage to set after this message. Must be one of the engine's STAGES enum.",
  "next_action_at_iso": "string or null — ISO 8601 timestamp for the next scheduled action (drip nudge, follow-up). null = no scheduled next action.",
  "garrison_flags": "array of strings — flags for Garrison's attention. See `garrison_flags catalog` below.",
  "notes": "string — internal notes for audit / debugging. Not sent to the client. Brief — 1-2 lines."
}
```

---

## Field-by-field

### `sms`

- 0 or 1-320 characters
- Empty string when SMS isn't appropriate (e.g., engagement letter delivery cover email)
- Opens with `[FirstName],` (and `this is attorney Garrison English.` only on FIRST_TOUCH)
- Sign-off: `— Garrison`
- No banned phrases (always-block tier always; pre-engagement tier in pre-engagement
  stages)
- Currently blocked at send by `SMS_SAFE_MODE=1`. Drafts are stored, not sent.

### `email_subject`

- Specific to the matter (state, matter type, OR specific question)
- Continues the thread (Re: + prior subject) on every reply after first touch
- Never generic ("Following up", "Your inquiry", "Legacy First Law")
- Length: 50-90 chars typical

### `email_body_text`

- Plain text, line breaks via `\n`
- 4-7 short paragraphs typical
- Pre-engagement footer required for stages: NEW_LEAD, FIRST_TOUCH, AWAITING_REPLY,
  TOUCHED, CONSULTED, IN_CONVERSATION, FEE_QUOTED, NEGOTIATING, FEE_AGREED
- Pre-engagement footer NOT included for stages: ENGAGEMENT_SIGNED, PAYMENT_PENDING,
  PAID_AWAITING_INTAKE, INTAKE_COMPLETE, CLIENT
- Sign-off (locked):
  ```
  — Garrison
  Garrison English
  Legacy First Law PLLC
  ```

### `email_body_html`

- Same content as `email_body_text` but with HTML
- Allowed tags: `<p>`, `<br>`, `<ul>`, `<ol>`, `<li>`, `<strong>`, `<em>`, `<a>`
- No inline `style=""`. No fonts. No `<div>`. No tables.
- HTML structure mirrors text structure paragraph-by-paragraph

### `new_stage`

Must be one of:

```
NEW_LEAD
FIRST_TOUCH
AWAITING_REPLY
TOUCHED
CONSULTED
IN_CONVERSATION
FEE_QUOTED
NEGOTIATING
FEE_AGREED
ENGAGEMENT_SENT
ENGAGEMENT_SIGNED      (alias: SIGNED)
PAYMENT_PENDING
PAID_AWAITING_INTAKE
INTAKE_COMPLETE
CLIENT
LOST_NO_RESPONSE
LOST_DECLINED
REFERRED_AMICUS_LEX
REFERRED_THALER
DO_NOT_CONTACT
```

Stage progression rules (engine-enforced — you cannot bypass):

- `PROTECTED_STAGES = ['ENGAGEMENT_SENT', 'SIGNED', 'PAYMENT_PENDING', 'CLIENT', 'CLIENT_ONBOARDING']`
  Claude / prompt output CANNOT set these. Only explicit human action via
  `event:engagement_sent`, `event:engagement_signed`, `event:payment_received` can.
- The engagement gate (Item #4 v1, v112) requires `is_work_authorized=true` OR
  `override_authorization=true` for `event:engagement_sent`.
- `REFERRED_AMICUS_LEX` and `DO_NOT_CONTACT` and `LOST_DECLINED` ARE settable from
  prompt output (route-out + stop-detect logic).

### `next_action_at_iso`

- ISO 8601 in UTC: `"2026-05-08T14:00:00Z"`
- null = no scheduled next action (engine uses default drip cadence)
- Use this to override default cadence (e.g., client asked for follow-up in 2 weeks)

### `garrison_flags`

Array of string flags. Engine writes these to `garrison_flags_json` and surfaces them
in the Command Center dashboard.

**Catalog:**

| Flag | Meaning | When to set |
|---|---|---|
| `CALL_REQUESTED` | **NEVER USE.** Client asked for a call — deflect in writing instead. | Never. The locked rules forbid setting this. |
| `SPANISH_DETECTED` | Inbound is in Spanish | Engine sets this automatically; prompts don't need to |
| `CAPACITY_OR_LITIGATION_GATE` | Capacity / litigation flag from classifier | Engine sets automatically |
| `MATTER_CONVERT` | Payment received, ready for matter conversion in Lawcus | Set on `PAID_AWAITING_INTAKE` |
| `SIGNATURE_DAY_7_NUDGE` | Day 7 of unsigned engagement letter | Set on Day 7 signature follow-up |
| `PAYMENT_DAY_10_PAUSE` | Day 10 of unpaid post-signature | Set on Day 10 payment follow-up |
| `NEGOTIATION_ESCALATE` | Client wants below-floor or out-of-schedule fee — Garrison decides | Set in negotiation stage when needed |
| `FEE_LOOKUP_MISS` | `lookupFee` returned null (matter/sub not in schedule) | Set when quote_readiness can't be reached |
| `UNCLASSIFIED_OBJECTION` | Inbound objection didn't match the 12 playbook categories | Set when objection playbook can't classify |
| `INVOICE_NEEDED` | Engagement signed — invoice creation needed | Set on `engagement_signed` event |
| `WORK_AUTH_OVERRIDE_USED` | Engagement letter sent via override path (not via `authorize_work`) | Engine sets when `override_authorization=true` is used |

### `notes`

- Internal — not visible to client
- 1-2 lines
- Format: action taken / lever used / any signal worth surfacing
- Example: `"Day-5 nudge: clarification offer with three concrete clauses to ask about. PA-specific IOLTA reference. No urgency."`

---

## Engine writeback

The engine writes the following fields to the conversation sheet from this JSON:

| Sheet column | Source field |
|---|---|
| `pending_sms` | `sms` |
| `pending_email_subject` | `email_subject` |
| `pending_email_body_text` | `email_body_text` |
| `pending_email_body_html` | `email_body_html` |
| `stage` | `new_stage` |
| `next_action_at` | `next_action_at_iso` |
| `garrison_flags_json` | `garrison_flags` (appended, not replaced) |
| `notes` | `notes` (appended, not replaced) |
| `messages_json` | engine appends an entry on send (not from this JSON directly) |

---

## Validation contract

The engine validates returned JSON before writing. If validation fails, engine flags
`PROMPT_OUTPUT_INVALID` and queues for Garrison review.

```
[ ] Object is valid JSON
[ ] All required keys present: sms, email_subject, email_body_text, email_body_html, new_stage, garrison_flags, notes
[ ] sms is string (may be empty)
[ ] email_* fields all non-empty (when an email is intended)
[ ] new_stage is in the STAGES enum
[ ] next_action_at_iso is ISO 8601 or null
[ ] garrison_flags is array of strings
[ ] No banned phrases in sms / email_body_text / email_body_html (per stage tier)
[ ] No `Esq.`, `we`, `our team` in any field
[ ] No em dashes in any field
[ ] No phone-call / video / meeting language anywhere
[ ] No legal predictions (claim form) anywhere
```

A draft that fails validation does NOT advance the stage. Engine retries once with the
specific failure noted; a second failure escalates to Garrison.
