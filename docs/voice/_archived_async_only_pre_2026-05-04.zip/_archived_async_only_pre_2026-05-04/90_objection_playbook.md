# Objection Playbook (cross-stage)

This is a lookup table the prompt system uses when the engine classifies an inbound as
an objection. Each entry: trigger phrases, the read, the move, sample reply.

Used by `20_stage_in_conversation.md` and `40_stage_negotiation.md`.

---

## 1. Price — raw

**Trigger phrases:** "too expensive", "more than I expected", "out of my budget",
"can you do it for less", "any flexibility on the fee", "any discount available".

**The read:** value isn't anchored yet, OR they have a real budget constraint.

**The move:** show the math (deliverables / fee = dollars per document). If hard no on
standard, offer a smaller real package — never a discount on the same package without
floor authorization.

**Sample:**
> The $3,500 covers seven separate documents — joint trust, two pour-over wills, deed,
> two POAs, two HCDs. A la carte that's $4,000+. The bundle is the discount. If $3,500
> is firmly outside the budget, the will + POA + HCD bundle at $1,500 covers the core
> and you upgrade to the trust later. Which fits?

---

## 2. Comparison — "I got a quote elsewhere"

**Trigger phrases:** "another attorney quoted me X", "got a cheaper quote", "my friend
used [firm] for less", "neighbor's lawyer charged Y".

**The read:** they're shopping. Could be a different package or a different service model.

**The move:** don't trash competition. Differentiate on speed and ease. Ask what was in
the comparison package — if it's the same scope and meaningfully cheaper, concede or
match if you have authority. If different scope, surface the difference.

**Sample:**
> Most attorneys can quote a similar bundle. The difference usually shows up in the
> process — I draft within 72 hours, all by text and email, no office, no calls, no
> driving. If their quote includes the same trust + wills + deed + POAs + directives I
> quoted you, the comparison is fair. If theirs is just trust + wills, you're comparing
> different packages. Want me to send a one-page list of what's in mine so you can A/B them?

---

## 3. Process anxiety — "is this real / valid"

**Trigger phrases:** "online lawyer thing", "want a real lawyer", "is this even valid",
"don't trust e-sign", "doesn't this need to be in person", "can these hold up in court".

**The read:** they want reassurance about credentials and document validity.

**The move:** confirm credential (without naming licensure states). Confirm e-sign /
remote-online-notary legality in their state. Offer optional hard-copy delivery for
final signed originals.

**Sample:**
> Two things: (1) I'm a licensed attorney with the same standing as any in-office firm —
> the difference is workflow, not credentials. (2) Electronic signatures for estate
> planning documents are legally valid under the UETA framework, and notarization (when
> needed) happens via remote online notary which is also legal. Once final docs are
> signed I can send hard-copy originals by mail or you can pick them up. The drafting
> and review is all by text and email; the final signing is whatever format you prefer.

---

## 4. Authority delay — "need to talk to my spouse / partner"

**Trigger phrases:** "need to talk to my husband / wife / partner", "let me run this by
my [partner]", "have to check with [name]".

**The read:** they need a co-decider in the loop. This is a real constraint, not a
stall.

**The move:** make it trivially easy. Send a one-paragraph forwardable summary they can
paste. Offer to email the partner directly if useful.

**Sample:**
> Here's a one-paragraph summary you can forward to him directly:
>
> "[firm summary — package, fee, deliverables, timeline, no office visit required, no
> calls]."
>
> If he wants me on the email, copy me at garrison@legacyfirstlaw.com and I'll answer
> any questions in writing. When you've talked it over, reply YES and I'll send the
> engagement letter the same day.

---

## 5. Timing — "not now / later / next month"

**Trigger phrases:** "now's not a good time", "let me get back to you", "after
[holiday/event]", "maybe next month".

**The read:** real timing constraint OR a soft no in a polite wrapper.

**The move:** acknowledge, set a follow-up commitment, plant ONE forward-looking
question that helps them decide.

**Sample:**
> No problem. I'll send one note in about a week unless you ping me sooner — no pressure
> either way. If it helps your thinking: the cost of waiting isn't the fee, it's that
> the documents you don't have right now don't work if you need them tomorrow. What's
> the one thing that would make the decision easier — a written scope, a sample
> document, or just time?

---

## 6. Insurance / employer benefit — "do you take [plan]"

**Trigger phrases:** "legal insurance through work", "homeowner's policy has a will
benefit", "in-network with [carrier]", "[employer] legal plan".

**The read:** they have a benefit and want to use it.

**The move:** factually answer. LFL is a flat-fee firm, not in-network. Their plan may
cover a basic will at no cost but limits the panel. If they want the full estate plan,
the flat fee from LFL is what they pay.

**Sample:**
> Most of those plans are network-based and LFL isn't in network with the major legal
> insurance carriers. The plans typically cover a basic will at no cost but limit the
> attorney to a network panel. If you want the full estate plan I described — trust +
> deed + POAs + directives — that's outside what those plans cover, and the flat fee from
> me is what you'd pay. If you only want the basic will and your plan covers it, that's
> a legitimately good use of the plan. Tell me which package you actually want and I'll
> guide you from there.

---

## 7. Doubt — "is the trust really necessary"

**Trigger phrases:** "do I really need a trust", "is a will enough", "my friend just
has a will", "trust seems excessive".

**The read:** they're scope-questioning. Could be uninformed, could be informed.

**The move:** validate the question. Explain when each piece matters, in their state.
Let them downgrade to a smaller real package if they want.

**Sample:**
> Honest answer: a will alone is fine if the goal is just naming guardians and
> beneficiaries and you're okay with probate. The reason most TX families with a home
> and kids want the trust is to skip probate (which in TX is independent administration
> but still 6-12 months and public). If a will is what you actually want, the simple
> will is $500, joint wills $1,000, will + POA + HCD bundle $1,000. Want me to scope
> the smaller package?

---

## 8. Distrust of remote / online — "I want a face-to-face"

**Trigger phrases:** "I want to come in", "can we meet", "rather do this in person",
"need to see a lawyer face to face".

**The read:** comfort preference, possibly anxiety about the matter (estate planning
brings up mortality).

**The move:** firm but warm. Restate the locked rule (async-only). Validate the
underlying need (questions answered thoroughly) and explain how you do that better in
writing than verbally. Do NOT bend.

**Sample:**
> I get it — for something important, sitting across from someone feels right. The
> reason I work in writing instead is that you get a permanent record of every answer,
> you can review at your pace, and there's no clock running. Bring me every question
> you'd ask in a face-to-face — long-form, every one — and I'll answer in writing today.
> If after that you still want to meet, that's fine, but most clients realize the
> writing-first answer was actually more thorough than the in-person version.

---

## 9. Trust transfer / specific feature — "does this cover [X]"

**Trigger phrases:** "does the trust handle [retirement accounts / business interest /
real estate in another state]", "what about my [specific asset]".

**The read:** they're qualifying scope on a specific asset class.

**The move:** answer factually. Use the FOLLOWUP LEVERS state-specific hooks (TX Lady
Bird Deeds, PA inheritance tax tier, etc.).

**Sample (TX, real estate in another state):**
> The trust covers any asset you transfer into it — including real estate in another
> state. The way that works: I draft the trust here, then for the out-of-state property
> I draft a deed under that state's rules to transfer ownership into the trust. The
> deed itself adds $500 (or sometimes a different amount depending on the state's
> recording fees). For TX assets, including your primary residence, the trust + deed
> are already in the $3,500 package. Want me to add the out-of-state deed scope to the
> engagement?

---

## 10. Death-conversation discomfort

**Trigger phrases:** "this is morbid", "don't want to think about dying", "isn't this
premature", "I'm only [age]".

**The read:** the matter is emotionally heavy. Don't push the consequences harder.

**The move:** validate. Reframe from "death planning" to "decision documentation." Let
the client pace.

**Sample:**
> Fair — this isn't a fun topic. The reframe that helps most clients: an estate plan
> isn't death planning, it's decision documentation. You're answering "if anything ever
> happens, what should the answer be" once, in writing, instead of leaving the answer
> to a court or a default. The drafting itself is matter-of-fact — I send the intake,
> you fill it out, I draft, you review. We can take it as fast or as slow as you need.

---

## 11. Asking for legal advice in writing — "tell me what to do"

**Trigger phrases:** "what should I do", "what would you do", "what's my best move",
"is [X] better than [Y]", "should I [specific action]".

**The read:** they want a recommendation. PRE-engagement = UPL territory. POST-engagement
= still careful, but you can answer scoped questions about documents you're drafting.

**The move (pre-engagement):** redirect to the structural answer ("here's how each
option works") without making the recommendation. Explicitly defer the recommendation
to after engagement.

**The move (post-engagement):** answer factually for the matter you're handling. Defer
specific advice on adjacent matters until they're scoped into a separate engagement.

**Sample (pre-engagement):**
> I can't make a specific recommendation before I've reviewed your situation in detail —
> that's the line where general information becomes legal advice and it requires the
> formal engagement first. What I can tell you is how each path actually works, and
> that's usually enough for the decision: [structural explanation, no recommendation].
> If you want my actual recommendation on which fits your situation, that's a 30-minute
> intake review and a written response after the engagement is signed.

**Sample (post-engagement):**
> Within the trust I'm drafting for you, the answer is [specific scoped answer]. If
> you're asking about something adjacent (e.g., a tax election, a separate business
> agreement) that's outside the current engagement — happy to scope a separate
> engagement if that's the right path.

---

## 12. Misclassified matter — they want litigation

**Trigger phrases:** "I'm being sued", "my [partner / family member] is suing me",
"need to file a lawsuit", "court date", "served".

**The read:** litigation. Not LFL's lane.

**The move:** redirect to Amicus Lex per RPC 7.2(b). Do NOT discuss the matter. Set
`new_stage = REFERRED_AMICUS_LEX`.

**Sample:**
> What you're describing is a contested matter, which is outside what I handle directly
> at LFL. I'm going to introduce you to my colleague at Amicus Lex who runs that
> practice — she'll reach out today. (Per RPC 7.2(b), Amicus Lex is a sister firm to
> LFL, ownership disclosed.)

---

## When the playbook doesn't match

If the inbound doesn't fit any of these 12 categories, fall back to the standard
in-conversation prompt (`20_stage_in_conversation.md`) and treat the inbound as a
qualification opportunity, not an objection. Set
`garrison_flags: ["UNCLASSIFIED_OBJECTION"]` so Garrison can review and add a new
playbook entry if the pattern recurs.
