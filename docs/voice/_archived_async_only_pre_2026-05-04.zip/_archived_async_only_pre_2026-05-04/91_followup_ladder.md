# Follow-Up Ladder (no-reply cadence)

When a lead goes quiet at any pre-engagement stage, the engine drips on this schedule.
Each nudge uses a DIFFERENT angle — repeating the same lever twice gets auto-rejected.

---

## Cadence (locked)

| Day | Channel | Purpose |
|---|---|---|
| Day 0 | First touch (per `10_stage_first_touch.md`) | Introduce + qualifying question |
| Day 2 | EMAIL | First nudge — STATE-SPECIFIC HOOK |
| Day 5 | EMAIL | Second nudge — SOCIAL PROOF |
| Day 7 | EMAIL | Third nudge — FEE TRANSPARENCY (mention bundle math, never quote without authority) |
| Day 10 | EMAIL | Fourth nudge — CONSEQUENCE-AS-QUESTION (a fresh angle, not the first-touch question) |
| Day 14 | EMAIL | Fifth nudge — BUSINESS-ESTATE CROSS-BUNDLE if applicable, else IMMEDIATE-PROTECTION + FUNDING CAVEAT |
| Day 21 | EMAIL | Final nudge — gracious close, set `new_stage = LOST_NO_RESPONSE` |

SMS is HARD-OFF (CLAUDE.md) — every drip is email.

---

## The seven levers

Each nudge picks ONE lever the prior nudges have NOT used. The engine tracks which
levers have been used in `state.followup_levers_used` (or equivalent metadata).

### Lever 1 — STATE-SPECIFIC HOOK

Show you know their jurisdiction. The most powerful lever — clients consistently rate
this as the moment they decided you were worth replying to.

| State | Hook |
|---|---|
| TX | Independent Administration probate vs. Dependent; Lady Bird Deeds (transfer-on-death deeds for primary residence); community property quirks; no state estate tax. |
| PA | 4.5% inheritance tax to children (12% siblings, 15% others); Register of Wills; 9-18 month probate; Pittsburgh and Philadelphia Surrogate's specifics. |
| IA | Iowa inheritance tax abolished 2025 (a clean reset for IA estate planning); 6-12 month probate; homestead protections. |
| ND | No estate or inheritance tax; TOD deeds; Uniform Probate Code; Bismarck-area court realities. |
| NJ | Estate tax abolished 2018; no inheritance tax to children/spouse; Surrogate's Court per county; modern Trust Code. |

**Sample (PA estate, Day 2 nudge):**
> Sarah, one PA-specific detail that comes up a lot: Pennsylvania charges a 4.5%
> inheritance tax on assets passing to children, on top of probate. A revocable trust
> doesn't avoid the tax (it's a transfer tax, not a probate tax) but it does avoid the
> probate filing, which can shave 9-18 months off the timeline. If your situation
> involves a home and direct-to-kids assets, that's the math worth knowing before you
> decide. Want me to walk through what your specific tax exposure looks like?

### Lever 2 — SOCIAL PROOF

> "I see this exact situation all the time."
> "I've handled dozens of [state] families with this setup."
> "This is one of the most common things I draft."

Use sparingly — once per lead, max. Don't fake numbers.

**Sample (TX joint estate, Day 5 nudge):**
> Quick context on your setup: TX, married, two kids, primary residence, modest estate.
> That's one of the most common configurations I draft — runs through my pipeline two
> or three times a week. The answer is almost always the joint trust + pour-over wills
> + deed package, exactly because it solves the three things you'd actually face
> (probate timeline, guardian clarity, deed transfer). Anything in particular pulling
> you back from saying yes?

### Lever 3 — FEE TRANSPARENCY

Reference a specific fee from the schedule (without quoting THE fee for THIS matter
unless authority is set). Mention the bundle math.

**Sample (Day 7 nudge, IA, simple will + POA):**
> One thing I want to make sure is clear on the fee side: the will + POA + HCD bundle
> is $1,000 (vs. $1,000 a la carte across the three documents — bundle is the
> discount). Drafted within 72 hours of intake. If $1,000 is the right fit and you want
> to keep going, reply YES and I'll send the engagement letter today.

### Lever 4 — CONSEQUENCE-AS-QUESTION (fresh angle)

A different consequence-question than the first-touch one. Estate examples:

- First touch: "Does your plan name a guardian for your kids?"
- Day 10: "If something happens to you tomorrow, would your spouse have clean access
  to the bank accounts or be waiting on the court?"
- Day 14 (if needed): "If both of you were gone, do your kids' caregivers have
  authority to make medical decisions for them, or does someone have to file with the
  court first?"

Business examples:

- First touch: "If you or your partner exits unexpectedly, is it written down what
  happens to your share?"
- Day 10: "If a dispute landed on your desk Monday, could you hand someone a signed
  contract that settles it?"
- Day 14: "If the LLC needs to take a loan or sign a major contract, who has authority
  to sign on its behalf — and is that documented?"

**Sample (Day 10 nudge, TX joint estate):**
> Sarah, one different angle on this: if both you and your husband were unavailable for
> a few weeks (illness, accident, anything), would the kids' caregiver have legal
> authority to make medical decisions for them, or would someone have to file with a
> court first? That's the gap most TX families don't realize exists in their plan
> until they need it. The HCD + guardian designation in the package handles it. Want me
> to walk through the language?

### Lever 5 — BUSINESS-ESTATE CROSS-BUNDLE

When they have business interests in the intake — even if they didn't ask for business
docs.

**Sample (Day 14 nudge, IA, single owner of small business):**
> One thing worth knowing about your situation: since you mentioned the business, I can
> bundle a personal trust that owns your business interest — keeps the business out of
> personal probate, makes succession clean if anything happens to you, and creates
> creditor separation between business and personal assets. The Trust + LLC bundle
> handles both at once. If you want me to scope that vs. the basic estate plan, just
> say so.

### Lever 6 — IMMEDIATE-PROTECTION + FUNDING CAVEAT

Reassure them on speed of effective coverage.

**Sample (Day 14 nudge, late-cycle):**
> Sarah, in case the speed angle helps: your plan goes into effect the moment you sign.
> Funding the trust (deed transfers, retitling accounts, beneficiary designation
> updates) happens right after — I include the deed in the package and walk you through
> the rest. Most clients are fully covered within two weeks of saying yes.

### Lever 7 — P.S. LINE

Every email closes with a short P.S. that reinforces ease or makes a specific
commitment. Used in COMBINATION with another lever, not as a standalone.

**Sample P.S. lines:**
> P.S. If you want, I can send a one-page sample of what the trust looks like before
> you decide — no commitment, just so you can see the actual document.

> P.S. The intake form takes about 30 minutes from your phone. That's the entire
> client-side time investment for the package.

> P.S. If timing is the issue, I can hold the standard fee for 30 days while you sort
> things on your end — just reply with a "still interested, need [N] weeks" and I'll
> mark it on hold.

---

## Engine integration

The engine should track per lead:

```
followup_levers_used: array  # ["STATE_HOOK","SOCIAL_PROOF","FEE_TRANSPARENCY",...]
last_followup_at: ISO timestamp
last_followup_lever: string  # the most recent lever used
```

Each new nudge:

1. Read `followup_levers_used`
2. Read `state_code`, `matter_type`, `sub_category`, `intent_score`, `key_facts`
3. Pick the lever for THIS day in the cadence (per cadence table)
4. If that lever has already been used: pick the next lever in the rotation that
   hasn't been
5. Generate the email
6. Append the lever to `followup_levers_used`

---

## Hard rules

```
[ ] Same lever NEVER used twice for the same lead
[ ] Same email body NEVER sent twice (the engine compares against `messages_json`)
[ ] State-specific hook must reference the lead's actual state, not generic
[ ] Day 21 = LOST_NO_RESPONSE, gracious close, no further drip
[ ] Pre-engagement footer auto-appended (FIRST_TOUCH through FEE_AGREED stages)
[ ] Post-engagement stages do NOT use this drip — see 60_stage_signature_followup.md
    and 70_stage_payment_followup.md
```
