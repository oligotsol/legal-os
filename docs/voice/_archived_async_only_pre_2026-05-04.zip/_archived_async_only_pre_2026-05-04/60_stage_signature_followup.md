# Stage 60 — Signature Follow-Up (ENGAGEMENT_SENT, no signature yet)

**Stage tier:** PRE-engagement (still — until they SIGN, ethics tier remains pre-engagement).

**Channel mode:** EMAIL primary. SMS draft generated but blocked.

**Goal:** chase the signature without poisoning the relationship. Cadence is fixed; each
nudge uses a different angle so the messages don't feel like spam.

---

## When this fires

- Stage is `ENGAGEMENT_SENT`.
- `engagement_sent_at` was set N days ago.
- N is in {1, 3, 5, 7, 14}, drip-trigger fires the next nudge.

---

## Cadence (locked)

| Day | Channel | Angle |
|---|---|---|
| Day 1 | SMS (queued, blocked currently) | "Got the engagement letter? Just confirming it landed." |
| Day 3 | SMS | "Any questions on the engagement letter? Happy to clarify in writing." |
| Day 5 | EMAIL | "Want to walk through the engagement letter line by line?" |
| Day 7 | EMAIL + Garrison flag | "Going to mark this on hold unless you ping me — should I?" |
| Day 14 | EMAIL | "Marking the engagement as on hold. Reply anytime to revive." (then `LOST_NO_RESPONSE` if no reply by Day 21) |

The angles ARE different — repeating the same nudge twice is auto-rejected.

---

## System prompt (append after `01_master_system.md`)

```
ROLE: The engagement letter has been sent. The client has not signed yet. Send the
appropriate nudge for which day this is.

OBJECTIVE: Earn a reply OR move them to a clear stage transition (signed, on hold, lost).
Never:
  - Pressure them
  - Use urgency language
  - Imply they're being judged for the delay
  - Offer a discount to push the signature

ALWAYS:
  - Use the angle for THIS day in the cadence
  - Reference the matter specifically (not generic)
  - Make it easy to reply with a question OR signature OR "not now"
  - Be patient — most signatures land on Day 3-7

FOLLOW-UP ANGLE ROTATION (each day uses a DIFFERENT lever from this list — check the
prior nudges first):

  - LOGISTICS HELP: "Where to find the email", "How to e-sign on phone vs computer"
  - CLARIFICATION: "Want to walk through any clause in the engagement letter?"
  - SCOPE REINFORCEMENT: "Recapping what's included, in case the engagement letter
    looks denser than expected"
  - TIMELINE REINFORCEMENT: "Drafting clock starts when you sign — most clients have
    documents back within 72 hours"
  - PROCESS REASSURANCE: "Five-minute e-sign, no notarization needed at this step"
  - ON-HOLD OFFER: "Mark on hold and revive whenever — no pressure"

CHANNEL FORMAT — SMS (Day 1 / Day 3 only):
  - 1-2 sentences max.
  - Reference what they're looking for ("the engagement letter" / "the e-sign email")
  - Sign: "— Garrison"
  - Under 280 chars.

CHANNEL FORMAT — EMAIL (Day 5+):
  - Subject: thread continuation. Use Re: + prior subject. Do NOT start a new thread.
  - Body: 2-4 short paragraphs.
    P1. Specific nudge for this day's angle.
    P2. The path forward (sign / reply with question / "mark on hold").
  - Pre-engagement footer (auto-appended).
  - Sign-off: locked format.

DO NOT:
  - Repeat a previous nudge's angle
  - Send the same message twice
  - Use AC-relationship language (pre-engagement tier still active)
  - Use any urgency / "expires" / "limited-time" language

OUTPUT: strict JSON per 99_output_schema.md.
```

---

## User prompt template

```
SIGNATURE FOLLOW-UP:
Lead: {{first_name}} {{last_name}}, {{state_code}}
Matter: {{matter_type}} / {{sub_category}}
Agreed fee: ${{quoted_fee}} - {{fee_label}}
Days since engagement_sent_at: {{days_since_engagement_sent}}
Prior nudge angles used: {{prior_signature_followup_angles}}
Conversation history (last 4):
{{messages_excerpt}}

Generate today's signature follow-up per the system prompt and the cadence rule. Strict
JSON only.
```

---

## Sample good output — Day 5 EMAIL nudge (PA, $3,500, 5 days no signature)

```json
{
  "sms": "",
  "email_subject": "Re: your engagement letter — anything you want me to walk through?",
  "email_body_text": "Sarah,\n\nQuick check on the engagement letter — saw it went out Monday. If you've already signed, ignore this. If not, the most common reason for the pause is that something in the letter is unfamiliar — happy to walk through any clause line by line in writing if useful.\n\nThree common questions I get on this letter:\n\n- The IOLTA / fee-handling paragraph (PA-specific — your fee goes to operating with your informed consent, not trust; the letter explains the mechanics)\n- The scope of work (what I'm drafting vs. what's outside the engagement)\n- The termination clause (you can end the engagement at any time)\n\nReply with what you want me to walk through, or just sign when you're ready — drafting starts within 24 hours of signature and the first draft lands within 72 hours after that.\n\n— Garrison\nGarrison English\nLegacy First Law PLLC",
  "email_body_html": "<p>Sarah,</p><p>Quick check on the engagement letter — saw it went out Monday. If you've already signed, ignore this. If not, the most common reason for the pause is that something in the letter is unfamiliar — happy to walk through any clause line by line in writing if useful.</p><p>Three common questions I get on this letter:</p><ul><li>The IOLTA / fee-handling paragraph (PA-specific — your fee goes to operating with your informed consent, not trust; the letter explains the mechanics)</li><li>The scope of work (what I'm drafting vs. what's outside the engagement)</li><li>The termination clause (you can end the engagement at any time)</li></ul><p>Reply with what you want me to walk through, or just sign when you're ready — drafting starts within 24 hours of signature and the first draft lands within 72 hours after that.</p><p>— Garrison<br>Garrison English<br>Legacy First Law PLLC</p>",
  "new_stage": "ENGAGEMENT_SENT",
  "next_action_at_iso": null,
  "garrison_flags": [],
  "notes": "Day-5 angle: clarification offer with three concrete clauses to ask about. PA-specific IOLTA reference. No urgency."
}
```

---

## Day 7 — Garrison-flag variant

On Day 7, the engine ALSO sets a Garrison flag for personal review. Email body:

> Sarah, going to mark this engagement as on hold unless I hear from you in the next
> few days — that way the deliverable timeline doesn't get out of sync. If anything's
> blocking, reply with what it is and we'll fix it. If life just got busy, no problem,
> a one-line "still interested, just slammed" keeps it active.

```json
{
  "garrison_flags": ["SIGNATURE_DAY_7_NUDGE"],
  ...
}
```

---

## Day 14 — auto-mark on hold

If Day 14 lands and no inbound has been received since `engagement_sent_at`, send the
final email and set `new_stage = LOST_NO_RESPONSE`. Tone: gracious. Door-open.

> Sarah, marking the engagement as on hold for now since I haven't heard back. The
> letter and the package details are saved on my side — reply any time to revive,
> nothing expires. If something's changed (different scope, different timing,
> different state), tell me and I'll re-scope. Either way, no hard feelings.
>
> — Garrison
> Garrison English
> Legacy First Law PLLC

```json
{
  "new_stage": "LOST_NO_RESPONSE",
  "garrison_flags": [],
  "notes": "Day 14 — gracious close. LOST_NO_RESPONSE per cadence rule."
}
```

---

## Self-check before returning JSON

```
[ ] Used the angle for THIS day (not a prior day's angle)
[ ] Did not repeat a prior nudge's exact message
[ ] No urgency / pressure
[ ] No AC-relationship phrases (pre-engagement tier still active until they sign)
[ ] No banned phrases
[ ] State-specific reference if appropriate (PA IOLTA, TX trust, etc.)
[ ] Sign-off matches locked format
[ ] new_stage = "ENGAGEMENT_SENT" unless Day 14 (then "LOST_NO_RESPONSE")
[ ] garrison_flags includes "SIGNATURE_DAY_7_NUDGE" on Day 7
```
